   
   function submitForm() {
        var qId = document.getElementById("quoteId").value;
        var tranDate = document.getElementById("transactionDate").value;
        var custName = document.getElementById("customerName").value;
        var custEmail = document.getElementById("customerEmail").value;
        var comment= document.getElementById("comment").value;
        localStorage.setItem("quoteId",qId.value);
        localStorage.setItem("TransactionDate",tranDate.value);
        localStorage.setItem("customerName",custName.value);
        localStorage.setItem("customerEmail",custEmail.value);
        localStorage.setItem("comment",comment.value);
         alert("Quote has been stored to localStorage");
    }
