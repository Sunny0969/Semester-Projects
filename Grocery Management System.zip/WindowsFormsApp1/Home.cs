﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void View_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewItem VI = new ViewItem();
            VI.Show();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateItem UI = new UpdateItem();
            UI.Show();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteItem DI = new DeleteItem();
            DI.Show();
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 F1  = new Form1();
            F1.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            this.Hide();
            add a = new add();
            a.Show();
        }
    }
}
