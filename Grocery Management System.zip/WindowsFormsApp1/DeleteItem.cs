﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class DeleteItem : Form
    {
        public DeleteItem()
        {
            InitializeComponent();
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 F1 = new Form1();
            F1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            String constring = @" Data Source=192.168.100.106;Initial Catalog=NewWork;Integrated Security=True ";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                String q = "delete from Table01 where Item_Id = " + Text1.Text.ToString();
                SqlCommand cmd = new SqlCommand(q, con); 
                int i = cmd.ExecuteNonQuery(); 
                if (i != 0)
                {
                    MessageBox.Show("Deleted Successfully!");
                }
                else
                    MessageBox.Show("Error!");
            }
            con.Close();



        }
    }
}
